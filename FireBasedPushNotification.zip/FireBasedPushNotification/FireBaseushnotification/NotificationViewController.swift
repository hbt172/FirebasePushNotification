//
//  NotificationViewController.swift
//  FireBaseushnotification
//
//  Created by Hardik on 31/10/18.
//  Copyright © 2018 Hardik. All rights reserved.
//

import UIKit
import UserNotifications
import UserNotificationsUI

class NotificationViewController: UIViewController, UNNotificationContentExtension {

    @IBOutlet var label: UILabel?
    @IBOutlet weak var lblSubTitle: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any required interface initialization here.
    }
    
    func didReceive(_ notification: UNNotification) {
        self.label?.text = notification.request.content.body
        self.lblTitle?.text = notification.request.content.title
        self.lblSubTitle?.text = notification.request.content.subtitle
    }
}
