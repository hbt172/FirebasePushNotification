//
//  ViewController.swift
//  FireBasedPushNotification
//
//  Created by Hardik on 31/10/18.
//  Copyright © 2018 Hardik. All rights reserved.
//

import UIKit
import UserNotifications
class ViewController: UIViewController, UNUserNotificationCenterDelegate {    
    override func viewDidLoad() {
        super.viewDidLoad()        
    }
    
    @IBAction func btnCreateLocalNotificationClick(_ sender: Any) {
        let content = UNMutableNotificationContent()
        content.title = "Hey this i simplified iOS"
        content.subtitle = "iOS Development is fun"
        content.body = "We are learing about iOS Local Notification"
        content.badge = 1
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)        
        let  request = UNNotificationRequest(identifier: "SimpifiedIOSNotification", content: content, trigger: trigger)
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {        
        //displaying the ios local notification when app is in foreground
        completionHandler([.alert, .badge, .sound])
    }
}
